python main.py
sleep 99999999999999999999999999999
sh start.sh